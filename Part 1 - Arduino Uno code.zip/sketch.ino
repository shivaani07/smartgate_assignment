#include <Servo.h>

#define TRIG_PIN 9
#define ECHO_PIN 10
#define LED_PIN 7
#define SERVO_PIN 6
#define CLOSED_GATE 90
#define OPEN_GATE 0
#define DURATION 5000
#define DISTANCE 20

Servo gateServo;

bool gateIsOpen = false;
unsigned long gateOpenedAt = 0;

void setup()
{
  Serial.begin(115200);
  pinMode(ECHO_PIN, INPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  gateServo.attach(SERVO_PIN);
  gateServo.write(CLOSED_GATE);
  digitalWrite(LED_PIN, LOW);
  Serial.println("--- SMART GATE SYSTEM IS READY ---");
}

long getDistance() 
{
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  long distance = duration * 0.034 / 2;
  return distance;
}

void blinkLED(int times, int delayMs) 
{
  for (int i = 0; i < times; i++) 
  {
    digitalWrite(LED_PIN, HIGH);
    delay(delayMs);
    digitalWrite(LED_PIN, LOW);
    delay(delayMs);
  }
}

void openGate() 
{
  Serial.println(">> Vehicle detected! Opening gate...");
  blinkLED(3, 150);
  gateServo.write(OPEN_GATE);
  digitalWrite(LED_PIN, HIGH);
  gateIsOpen = true;
  gateOpenedAt = millis();
}

void closeGate() 
{
  Serial.println(">> Path clear. Closing gate...");
  blinkLED(3, 150);
  gateServo.write(CLOSED_GATE);
  digitalWrite(LED_PIN, LOW);
  gateIsOpen = false;
  Serial.println(">> Gate closed and secured.");
}

void loop() 
{
  long distance = getDistance();
  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  if (!gateIsOpen) 
  {
    if (distance > 0 && distance < DISTANCE) 
    {
      openGate();
    }
  } 
  else 
  {
    unsigned long timeElapsed = millis() - gateOpenedAt;
    if (timeElapsed >= DURATION) 
    {
      if (distance == 0 || distance >= DISTANCE)
      {
        closeGate();
      } 
      else 
      {
        Serial.println(">> Path still blocked. Waiting...");
      }
    }
  }
  delay(500);
}